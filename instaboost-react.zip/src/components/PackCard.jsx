export default function PackCard({ title, price }) {
  return (
    <div className="bg-white shadow p-4 rounded-lg text-center">
      <h3 className="text-xl font-semibold">{title}</h3>
      <p className="text-gray-700 mb-4">{price}€</p>
      <a href="/produit" className="bg-pink-600 text-white px-4 py-2 rounded hover:bg-pink-700">Commander</a>
    </div>
  );
}
