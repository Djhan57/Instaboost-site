import { Link } from "react-router-dom";

export default function Header() {
  return (
    <header className="bg-gray-900 text-white py-4">
      <div className="container mx-auto flex justify-between items-center px-4">
        <h1 className="text-xl font-bold">InstaBoost</h1>
        <nav>
          <Link className="mx-2 hover:underline" to="/">Accueil</Link>
          <Link className="mx-2 hover:underline" to="/produit">Produit</Link>
          <Link className="mx-2 hover:underline" to="/panier">Panier</Link>
        </nav>
      </div>
    </header>
  );
}
