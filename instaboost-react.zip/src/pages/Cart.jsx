import { useState, useEffect } from "react";

export default function Cart() {
  const [cart, setCart] = useState([]);

  useEffect(() => {
    const saved = JSON.parse(localStorage.getItem("cart")) || [];
    setCart(saved);
  }, []);

  const removeItem = (index) => {
    const newCart = cart.filter((_, i) => i !== index);
    setCart(newCart);
    localStorage.setItem("cart", JSON.stringify(newCart));
  };

  const clearCart = () => {
    if (confirm("Vider le panier ?")) {
      localStorage.removeItem("cart");
      setCart([]);
    }
  };

  const total = cart.reduce((acc, item) => acc + item.price, 0);

  return (
    <div>
      <h2 className="text-2xl font-bold mb-4">Votre Panier</h2>
      <table className="w-full text-left border-collapse">
        <thead>
          <tr>
            <th className="border-b p-2">Pack</th>
            <th className="border-b p-2">Utilisateur</th>
            <th className="border-b p-2">Email</th>
            <th className="border-b p-2">Prix</th>
            <th className="border-b p-2">Action</th>
          </tr>
        </thead>
        <tbody>
          {cart.map((item, i) => (
            <tr key={i}>
              <td className="p-2">{item.pack}</td>
              <td className="p-2">{item.username}</td>
              <td className="p-2">{item.email}</td>
              <td className="p-2">{item.price.toFixed(2)}€</td>
              <td className="p-2"><button onClick={() => removeItem(i)} className="text-red-600">Supprimer</button></td>
            </tr>
          ))}
        </tbody>
      </table>
      <p className="text-right font-bold mt-4">Total : {total.toFixed(2)}€</p>
      <button onClick={clearCart} className="mt-4 bg-red-500 text-white px-4 py-2 rounded hover:bg-red-600">Vider le panier</button>
    </div>
  );
}
