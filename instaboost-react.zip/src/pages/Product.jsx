import { useState } from "react";

export default function Product() {
  const [form, setForm] = useState({ username: "", email: "", pack: "100 followers" });
  const [error, setError] = useState("");

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!form.username || !form.email) {
      setError("Tous les champs sont obligatoires.");
      return;
    }
    const price = form.pack === "1000 followers" ? 17.99 : form.pack === "500 followers" ? 9.99 : 2.99;
    const cart = JSON.parse(localStorage.getItem("cart")) || [];
    cart.push({ ...form, price });
    localStorage.setItem("cart", JSON.stringify(cart));
    alert("Ajouté au panier !");
  };

  return (
    <form onSubmit={handleSubmit} className="max-w-md mx-auto bg-white p-6 shadow rounded">
      <h2 className="text-xl font-semibold mb-4">Commande</h2>
      {error && <p className="text-red-500 mb-2">{error}</p>}
      <input type="text" name="username" placeholder="Nom d'utilisateur Instagram" className="border p-2 w-full mb-4" onChange={handleChange} />
      <input type="email" name="email" placeholder="Email" className="border p-2 w-full mb-4" onChange={handleChange} />
      <select name="pack" className="border p-2 w-full mb-4" onChange={handleChange}>
        <option value="100 followers">100 followers</option>
        <option value="500 followers">500 followers</option>
        <option value="1000 followers">1000 followers</option>
      </select>
      <button type="submit" className="bg-pink-600 text-white px-4 py-2 rounded hover:bg-pink-700">Ajouter au panier</button>
    </form>
  );
}
