import PackCard from "../components/PackCard";

export default function Home() {
  const packs = [
    { title: "100 followers", price: 2.99 },
    { title: "500 followers", price: 9.99 },
    { title: "1000 followers", price: 17.99 },
  ];

  return (
    <div>
      <h2 className="text-2xl font-bold text-center mb-6">Choisissez votre pack</h2>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {packs.map((pack, idx) => (
          <PackCard key={idx} title={pack.title} price={pack.price} />
        ))}
      </div>
    </div>
  );
}
